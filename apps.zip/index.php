<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>App Store</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Screenshots Modal */
        .screenshots-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        
        .screenshots-container {
            max-width: 90%;
            max-height: 90%;
            position: relative;
        }
        
        .screenshots-slider {
            display: flex;
            overflow-x: auto;
            gap: 20px;
            padding: 20px;
            scroll-snap-type: x mandatory;
        }
        
        .screenshot-slide {
            flex: 0 0 auto;
            width: 300px;
            height: 600px;
            scroll-snap-align: start;
        }
        
        .screenshot-slide img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            border-radius: 12px;
        }
        
        .close-modal {
            position: absolute;
            top: 20px;
            right: 20px;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border: none;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            font-size: 1.2rem;
            cursor: pointer;
            backdrop-filter: blur(10px);
        }
        
        .screenshot-nav {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border: none;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            font-size: 1.2rem;
            cursor: pointer;
            backdrop-filter: blur(10px);
        }
        
        .prev-screenshot {
            left: 20px;
        }
        
        .next-screenshot {
            right: 20px;
        }
        
        .screenshot-indicators {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            gap: 10px;
        }
        
        .screenshot-indicator {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.5);
            cursor: pointer;
        }
        
        .screenshot-indicator.active {
            background: white;
        }
        
        /* App Card Enhancements */
        .app-card {
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .app-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }
        
        .app-icon {
            transition: transform 0.3s ease;
        }
        
        .app-card:hover .app-icon {
            transform: scale(1.1);
        }
        
        /* Loading Animation */
        .loading-apps {
            text-align: center;
            padding: 40px;
            color: #666;
        }
        
        .loading-spinner {
            border: 3px solid #f3f3f3;
            border-top: 3px solid #4285f4;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        /* App Info Tooltip */
        .app-tooltip {
            position: absolute;
            background: white;
            border-radius: 8px;
            padding: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            z-index: 100;
            max-width: 300px;
            display: none;
        }
        
        .app-tooltip h4 {
            margin: 0 0 5px 0;
            color: #333;
        }
        
        .app-tooltip p {
            margin: 0;
            font-size: 0.9rem;
            color: #666;
        }
    </style>
</head>
<body>
    <!-- Screenshots Modal -->
    <div class="screenshots-modal" id="screenshotsModal">
        <button class="close-modal" id="closeModal">&times;</button>
        <button class="screenshot-nav prev-screenshot" id="prevScreenshot">
            <i class="fas fa-chevron-left"></i>
        </button>
        <button class="screenshot-nav next-screenshot" id="nextScreenshot">
            <i class="fas fa-chevron-right"></i>
        </button>
        
        <div class="screenshots-container">
            <div class="screenshots-slider" id="screenshotsSlider">
                <!-- Screenshots will be loaded here -->
            </div>
        </div>
        
        <div class="screenshot-indicators" id="screenshotIndicators">
            <!-- Indicators will be loaded here -->
        </div>
    </div>

    <!-- Left Side Menu -->
    <div class="side-menu" id="sideMenu">
        <div class="menu-header">
            <h3>Menu</h3>
            <button class="close-menu" id="closeMenu">&times;</button>
        </div>
        <ul class="menu-items">
            <li><a href="#" id="forDevelopers">For Developers</a></li>
            <li><a href="#">Settings</a></li>
            <li><a href="#">Help & Feedback</a></li>
        </ul>
    </div>

    <!-- Top Navigation Bar -->
    <header class="top-nav">
        <div class="nav-container">
            <button class="hamburger" id="hamburger">
                <i class="fas fa-bars"></i>
            </button>
            <div class="logo">
                <h2>App Store</h2>
            </div>
            <nav class="nav-tabs">
                <a href="#" class="tab active" data-tab="for-you">For You</a>
                <a href="#" class="tab" data-tab="top-charts">Top Charts</a>
                <a href="#" class="tab" data-tab="kids">Kids</a>
                <a href="#" class="tab" data-tab="premium">Premium</a>
                <a href="#" class="tab" data-tab="apps">Apps</a>
                <a href="#" class="tab" data-tab="games">Games</a>
            </nav>
            <div class="search-icon">
                <a href="search.php"><i class="fas fa-search"></i></a>
            </div>
        </div>
    </header>

    <!-- Featured Banner -->
    <section class="featured-banner" id="featuredBanner">
        <!-- Content loaded via JavaScript -->
    </section>

    <!-- Scrollable App Sections -->
    <main class="main-content">
        <section class="app-section" id="suggested-section">
            <h2 class="section-title">Suggested for You</h2>
            <div class="scroll-container">
                <div class="app-grid" id="suggestedApps">
                    <div class="loading-apps">
                        <div class="loading-spinner"></div>
                        <p>Loading apps...</p>
                    </div>
                </div>
            </div>
        </section>

        <section class="app-section" id="trending-section">
            <h2 class="section-title">Trending Apps</h2>
            <div class="scroll-container">
                <div class="app-grid" id="trendingApps">
                    <div class="loading-apps">
                        <div class="loading-spinner"></div>
                        <p>Loading apps...</p>
                    </div>
                </div>
            </div>
        </section>

        <section class="app-section" id="top-games-section">
            <h2 class="section-title">Top Games</h2>
            <div class="scroll-container">
                <div class="app-grid" id="topGames">
                    <div class="loading-apps">
                        <div class="loading-spinner"></div>
                        <p>Loading games...</p>
                    </div>
                </div>
            </div>
        </section>

        <section class="app-section" id="recommended-section">
            <h2 class="section-title">Recommended For You</h2>
            <div class="scroll-container">
                <div class="app-grid" id="recommendedApps">
                    <div class="loading-apps">
                        <div class="loading-spinner"></div>
                        <p>Loading apps...</p>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- Bottom Navigation Bar -->
    <footer class="bottom-nav">
        <a href="#" class="nav-item active">
            <i class="fas fa-gamepad"></i>
            <span>Games</span>
        </a>
        <a href="#" class="nav-item">
            <i class="fas fa-th-large"></i>
            <span>Apps</span>
        </a>
        <a href="search.php" class="nav-item">
            <i class="fas fa-search"></i>
            <span>Search</span>
        </a>
        <a href="#" class="nav-item">
            <i class="fas fa-user"></i>
            <span>Profile</span>
        </a>
    </footer>

    <script>
        // DOM Elements
        const hamburger = document.getElementById('hamburger');
        const sideMenu = document.getElementById('sideMenu');
        const closeMenu = document.getElementById('closeMenu');
        const forDevelopers = document.getElementById('forDevelopers');
        const tabs = document.querySelectorAll('.tab');
        const featuredBanner = document.getElementById('featuredBanner');
        const appSections = {
            suggested: document.getElementById('suggestedApps'),
            trending: document.getElementById('trendingApps'),
            topGames: document.getElementById('topGames'),
            recommended: document.getElementById('recommendedApps')
        };

        // Screenshots Modal Elements
        const screenshotsModal = document.getElementById('screenshotsModal');
        const closeModal = document.getElementById('closeModal');
        const prevScreenshot = document.getElementById('prevScreenshot');
        const nextScreenshot = document.getElementById('nextScreenshot');
        const screenshotsSlider = document.getElementById('screenshotsSlider');
        const screenshotIndicators = document.getElementById('screenshotIndicators');

        let currentApp = null;
        let currentScreenshotIndex = 0;

        // Real Apps Data (Replace with API calls in production)
        const realApps = [
            {
                id: 1,
                name: 'Photo Editor Pro',
                package: 'com.photoeditor.pro',
                description: 'Professional photo editing app with advanced filters, tools, and effects. Perfect for enhancing your photos with just a few taps.',
                category: 'Photo & Video',
                type: 'app',
                icon_url: 'uploads/icons/photo_editor_icon.png',
                file_size_mb: 8.3,
                rating: 4.5,
                downloads: 15000,
                version: '2.1.0',
                min_android: '5.0',
                screenshots: [
                    'uploads/screenshots/photo_editor_1.jpg',
                    'uploads/screenshots/photo_editor_2.jpg',
                    'uploads/screenshots/photo_editor_3.jpg',
                    'uploads/screenshots/photo_editor_4.jpg'
                ]
            },
            {
                id: 2,
                name: 'Racing Masters',
                package: 'com.racing.masters',
                description: 'Experience high-speed racing with realistic graphics and multiple game modes. Compete with players worldwide!',
                category: 'Racing',
                type: 'game',
                icon_url: 'uploads/icons/racing_game_icon.png',
                file_size_mb: 45.2,
                rating: 4.8,
                downloads: 23000,
                version: '1.5.2',
                min_android: '6.0',
                screenshots: [
                    'uploads/screenshots/racing_1.jpg',
                    'uploads/screenshots/racing_2.jpg',
                    'uploads/screenshots/racing_3.jpg',
                    'uploads/screenshots/racing_4.jpg',
                    'uploads/screenshots/racing_5.jpg'
                ]
            },
            {
                id: 3,
                name: 'Music Stream',
                package: 'com.music.stream',
                description: 'Stream millions of songs, create playlists, and discover new music. Your personal music companion.',
                category: 'Music & Audio',
                type: 'app',
                icon_url: 'uploads/icons/music_app_icon.png',
                file_size_mb: 12.7,
                rating: 4.3,
                downloads: 18000,
                version: '3.0.1',
                min_android: '5.1',
                screenshots: [
                    'uploads/screenshots/music_1.jpg',
                    'uploads/screenshots/music_2.jpg',
                    'uploads/screenshots/music_3.jpg'
                ]
            },
            {
                id: 4,
                name: 'Puzzle Quest',
                package: 'com.puzzle.quest',
                description: 'Challenging puzzle game with hundreds of levels and brain-teasing challenges. Perfect for puzzle lovers!',
                category: 'Puzzle',
                type: 'game',
                icon_url: 'uploads/icons/puzzle_game_icon.png',
                file_size_mb: 32.5,
                rating: 4.6,
                downloads: 12500,
                version: '1.2.5',
                min_android: '5.0',
                screenshots: [
                    'uploads/screenshots/puzzle_1.jpg',
                    'uploads/screenshots/puzzle_2.jpg',
                    'uploads/screenshots/puzzle_3.jpg',
                    'uploads/screenshots/puzzle_4.jpg'
                ]
            },
            {
                id: 5,
                name: 'Fitness Tracker',
                package: 'com.fitness.tracker',
                description: 'Track your workouts, monitor progress, and achieve your fitness goals with personalized plans.',
                category: 'Health & Fitness',
                type: 'app',
                icon_url: 'uploads/icons/fitness_app_icon.png',
                file_size_mb: 15.8,
                rating: 4.4,
                downloads: 8900,
                version: '2.3.0',
                min_android: '6.0',
                screenshots: [
                    'uploads/screenshots/fitness_1.jpg',
                    'uploads/screenshots/fitness_2.jpg',
                    'uploads/screenshots/fitness_3.jpg'
                ]
            },
            {
                id: 6,
                name: 'Language Learn',
                package: 'com.language.learn',
                description: 'Learn new languages with interactive lessons, speech recognition, and progress tracking.',
                category: 'Education',
                type: 'app',
                icon_url: 'uploads/icons/language_app_icon.png',
                file_size_mb: 28.3,
                rating: 4.7,
                downloads: 11200,
                version: '1.8.2',
                min_android: '5.1',
                screenshots: [
                    'uploads/screenshots/language_1.jpg',
                    'uploads/screenshots/language_2.jpg',
                    'uploads/screenshots/language_3.jpg',
                    'uploads/screenshots/language_4.jpg'
                ]
            }
        ];

        // Event Listeners
        document.addEventListener('DOMContentLoaded', function() {
            // Load initial data
            loadFeaturedApp();
            loadAppSections();
            
            // Set up event listeners
            hamburger.addEventListener('click', toggleSideMenu);
            closeMenu.addEventListener('click', toggleSideMenu);
            forDevelopers.addEventListener('click', redirectToDeveloperUpload);
            
            // Tab switching
            tabs.forEach(tab => {
                tab.addEventListener('click', function(e) {
                    e.preventDefault();
                    switchTab(this.dataset.tab);
                });
            });
            
            // Screenshots modal events
            closeModal.addEventListener('click', closeScreenshotsModal);
            prevScreenshot.addEventListener('click', showPrevScreenshot);
            nextScreenshot.addEventListener('click', showNextScreenshot);
            
            // Close modal on background click
            screenshotsModal.addEventListener('click', function(e) {
                if (e.target === screenshotsModal) {
                    closeScreenshotsModal();
                }
            });
            
            // Keyboard navigation for screenshots
            document.addEventListener('keydown', function(e) {
                if (screenshotsModal.style.display === 'flex') {
                    if (e.key === 'Escape') closeScreenshotsModal();
                    if (e.key === 'ArrowLeft') showPrevScreenshot();
                    if (e.key === 'ArrowRight') showNextScreenshot();
                }
            });
            
            // Infinite scroll
            window.addEventListener('scroll', handleScroll);
        });

        // Toggle Side Menu
        function toggleSideMenu() {
            sideMenu.classList.toggle('active');
        }

        // Redirect to Developer Upload
        function redirectToDeveloperUpload() {
            window.location.href = 'developer-upload.php';
        }

        // Switch Tabs
        function switchTab(tabName) {
            // Remove active class from all tabs
            tabs.forEach(tab => tab.classList.remove('active'));
            
            // Add active class to clicked tab
            document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
            
            // Load content for the selected tab
            loadTabContent(tabName);
        }

        // Load Featured App
        function loadFeaturedApp() {
            const featuredApp = realApps[0]; // First app as featured
            
            featuredBanner.innerHTML = `
                <div class="banner-content">
                    <div class="banner-icon">
                        <i class="fas fa-${featuredApp.type === 'game' ? 'gamepad' : 'mobile-alt'}"></i>
                    </div>
                    <div class="banner-text">
                        <h2>${featuredApp.name}</h2>
                        <p>${featuredApp.description}</p>
                        <button class="install-btn" onclick="viewAppDetail(${featuredApp.id})">Install</button>
                    </div>
                </div>
            `;
        }

        // Load App Sections
        function loadAppSections() {
            // Suggested Apps (Mix of apps and games)
            const suggestedApps = [...realApps].sort(() => 0.5 - Math.random()).slice(0, 6);
            renderAppGrid(appSections.suggested, suggestedApps);
            
            // Trending Apps (Highest rated apps)
            const trendingApps = realApps
                .filter(app => app.type === 'app')
                .sort((a, b) => b.rating - a.rating)
                .slice(0, 6);
            renderAppGrid(appSections.trending, trendingApps);
            
            // Top Games (Highest rated games)
            const topGames = realApps
                .filter(app => app.type === 'game')
                .sort((a, b) => b.rating - a.rating)
                .slice(0, 6);
            renderAppGrid(appSections.topGames, topGames);
            
            // Recommended Apps (Most downloaded)
            const recommendedApps = [...realApps]
                .sort((a, b) => b.downloads - a.downloads)
                .slice(0, 6);
            renderAppGrid(appSections.recommended, recommendedApps);
        }

        // Render App Grid
        function renderAppGrid(container, apps) {
            container.innerHTML = '';
            
            if (apps.length === 0) {
                container.innerHTML = '<div class="loading-apps"><p>No apps found</p></div>';
                return;
            }
            
            apps.forEach(app => {
                const appCard = document.createElement('div');
                appCard.className = 'app-card';
                appCard.innerHTML = `
                    <div class="app-icon" onclick="showAppScreenshots(${app.id})">
                        <i class="fas fa-${app.type === 'game' ? 'gamepad' : 'mobile-alt'}"></i>
                    </div>
                    <div class="app-name">${app.name}</div>
                    <div class="app-category">${app.category}</div>
                    <div class="app-rating">
                        <i class="fas fa-star"></i>
                        <span>${app.rating}</span>
                    </div>
                    <button class="card-install-btn" onclick="viewAppDetail(${app.id})">Install</button>
                `;
                container.appendChild(appCard);
            });
        }

        // Show App Screenshots
        function showAppScreenshots(appId) {
            const app = realApps.find(a => a.id === appId);
            if (!app || !app.screenshots || app.screenshots.length === 0) {
                alert('No screenshots available for this app');
                return;
            }
            
            currentApp = app;
            currentScreenshotIndex = 0;
            
            // Load screenshots
            screenshotsSlider.innerHTML = '';
            screenshotIndicators.innerHTML = '';
            
            app.screenshots.forEach((screenshot, index) => {
                const slide = document.createElement('div');
                slide.className = 'screenshot-slide';
                slide.innerHTML = `<img src="${screenshot}" alt="${app.name} Screenshot ${index + 1}" onerror="this.src='https://via.placeholder.com/300x600/4285f4/ffffff?text=Screenshot+${index + 1}'">`;
                screenshotsSlider.appendChild(slide);
                
                const indicator = document.createElement('div');
                indicator.className = `screenshot-indicator ${index === 0 ? 'active' : ''}`;
                indicator.addEventListener('click', () => goToScreenshot(index));
                screenshotIndicators.appendChild(indicator);
            });
            
            // Show modal
            screenshotsModal.style.display = 'flex';
            document.body.style.overflow = 'hidden';
            
            // Update navigation
            updateScreenshotNavigation();
        }

        // Close Screenshots Modal
        function closeScreenshotsModal() {
            screenshotsModal.style.display = 'none';
            document.body.style.overflow = 'auto';
            currentApp = null;
            currentScreenshotIndex = 0;
        }

        // Show Previous Screenshot
        function showPrevScreenshot() {
            if (currentScreenshotIndex > 0) {
                currentScreenshotIndex--;
                goToScreenshot(currentScreenshotIndex);
            }
        }

        // Show Next Screenshot
        function showNextScreenshot() {
            if (currentApp && currentScreenshotIndex < currentApp.screenshots.length - 1) {
                currentScreenshotIndex++;
                goToScreenshot(currentScreenshotIndex);
            }
        }

        // Go to Specific Screenshot
        function goToScreenshot(index) {
            if (!currentApp) return;
            
            currentScreenshotIndex = index;
            const slideWidth = screenshotsSlider.children[0].offsetWidth + 20; // width + gap
            screenshotsSlider.scrollLeft = slideWidth * index;
            
            // Update indicators
            const indicators = screenshotIndicators.querySelectorAll('.screenshot-indicator');
            indicators.forEach((indicator, i) => {
                indicator.classList.toggle('active', i === index);
            });
            
            updateScreenshotNavigation();
        }

        // Update Screenshot Navigation
        function updateScreenshotNavigation() {
            if (!currentApp) return;
            
            prevScreenshot.style.display = currentScreenshotIndex > 0 ? 'block' : 'none';
            nextScreenshot.style.display = currentScreenshotIndex < currentApp.screenshots.length - 1 ? 'block' : 'none';
        }

        // Load Tab Content
        function loadTabContent(tabName) {
            let filteredApps = [];
            
            switch(tabName) {
                case 'apps':
                    filteredApps = realApps.filter(app => app.type === 'app');
                    break;
                case 'games':
                    filteredApps = realApps.filter(app => app.type === 'game');
                    break;
                case 'top-charts':
                    filteredApps = [...realApps].sort((a, b) => b.downloads - a.downloads);
                    break;
                case 'kids':
                    filteredApps = realApps.filter(app => 
                        app.category.includes('Education') || 
                        app.category.includes('Puzzle') ||
                        app.rating >= 4.0
                    );
                    break;
                case 'premium':
                    filteredApps = realApps.filter(app => app.rating >= 4.5);
                    break;
                default:
                    filteredApps = realApps;
            }
            
            // Update all sections with filtered content
            renderAppGrid(appSections.suggested, filteredApps.slice(0, 6));
            renderAppGrid(appSections.trending, filteredApps.slice(0, 6));
            renderAppGrid(appSections.topGames, filteredApps.filter(app => app.type === 'game').slice(0, 6));
            renderAppGrid(appSections.recommended, filteredApps.slice(0, 6));
        }

        // Handle Infinite Scroll
        function handleScroll() {
            const { scrollTop, scrollHeight, clientHeight } = document.documentElement;
            
            if (scrollTop + clientHeight >= scrollHeight - 100) {
                loadMoreApps();
            }
        }

        // Load More Apps (for infinite scroll)
        function loadMoreApps() {
            // In a real app, this would fetch more apps from an API
            console.log('Loading more apps...');
            
            // Simulate loading more apps
            setTimeout(() => {
                const moreApps = [...realApps].sort(() => 0.5 - Math.random()).slice(0, 3);
                moreApps.forEach(app => {
                    const appCard = document.createElement('div');
                    appCard.className = 'app-card';
                    appCard.innerHTML = `
                        <div class="app-icon" onclick="showAppScreenshots(${app.id})">
                            <i class="fas fa-${app.type === 'game' ? 'gamepad' : 'mobile-alt'}"></i>
                        </div>
                        <div class="app-name">${app.name}</div>
                        <div class="app-category">${app.category}</div>
                        <div class="app-rating">
                            <i class="fas fa-star"></i>
                            <span>${app.rating}</span>
                        </div>
                        <button class="card-install-btn" onclick="viewAppDetail(${app.id})">Install</button>
                    `;
                    appSections.suggested.appendChild(appCard);
                });
            }, 1000);
        }

        // View App Detail
        function viewAppDetail(appId) {
            window.location.href = `app-detail.php?id=${appId}`;
        }

        // Auto-scroll screenshots
        let autoScrollInterval;
        
        function startAutoScroll() {
            if (currentApp && currentApp.screenshots.length > 1) {
                autoScrollInterval = setInterval(() => {
                    if (currentScreenshotIndex < currentApp.screenshots.length - 1) {
                        showNextScreenshot();
                    } else {
                        goToScreenshot(0);
                    }
                }, 3000);
            }
        }
        
        function stopAutoScroll() {
            clearInterval(autoScrollInterval);
        }
        
        // Start auto-scroll when modal opens
        screenshotsModal.addEventListener('mouseenter', stopAutoScroll);
        screenshotsModal.addEventListener('mouseleave', startAutoScroll);
    </script>
</body>
</html>