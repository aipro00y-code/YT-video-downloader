<?php
session_start();
// In real app, check developer authentication
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Developer Dashboard - App Store</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .dashboard-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        .stat-number {
            font-size: 2rem;
            font-weight: bold;
            color: #4285f4;
            margin-bottom: 5px;
        }
        .stat-label {
            color: #666;
            font-size: 0.9rem;
        }
        .app-list {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .app-item {
            display: flex;
            align-items: center;
            padding: 15px 20px;
            border-bottom: 1px solid #eee;
        }
        .app-item:last-child {
            border-bottom: none;
        }
        .app-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            background: #f0f0f0;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 1.2rem;
            color: #4285f4;
        }
        .app-info {
            flex: 1;
        }
        .app-name {
            font-weight: 500;
            margin-bottom: 5px;
        }
        .app-meta {
            font-size: 0.8rem;
            color: #666;
        }
        .app-status {
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 500;
        }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-approved { background: #d4edda; color: #155724; }
        .status-rejected { background: #f8d7da; color: #721c24; }
        .dashboard-actions {
            margin-bottom: 20px;
            display: flex;
            gap: 10px;
        }
        .action-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 500;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        .btn-primary {
            background: #4285f4;
            color: white;
        }
        .btn-secondary {
            background: #f8f9fa;
            color: #333;
            border: 1px solid #ddd;
        }
    </style>
</head>
<body>
    <!-- Top Navigation Bar -->
    <header class="top-nav">
        <div class="nav-container">
            <a href="index.php" class="back-btn">
                <i class="fas fa-arrow-left"></i>
            </a>
            <div class="logo">
                <h2>Developer Dashboard</h2>
            </div>
            <div class="nav-actions">
                <a href="developer-upload.php" class="nav-btn">
                    <i class="fas fa-plus"></i> Upload New
                </a>
            </div>
        </div>
    </header>

    <div class="upload-container">
        <!-- Dashboard Stats -->
        <div class="dashboard-stats">
            <div class="stat-card">
                <div class="stat-number" id="totalApps">0</div>
                <div class="stat-label">Total Apps</div>
            </div>
            <div class="stat-card">
                <div class="stat-number" id="approvedApps">0</div>
                <div class="stat-label">Approved</div>
            </div>
            <div class="stat-card">
                <div class="stat-number" id="pendingApps">0</div>
                <div class="stat-label">Pending</div>
            </div>
            <div class="stat-card">
                <div class="stat-number" id="totalDownloads">0</div>
                <div class="stat-label">Total Downloads</div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="dashboard-actions">
            <a href="developer-upload.php" class="action-btn btn-primary">
                <i class="fas fa-upload"></i> Upload New App
            </a>
            <a href="admin-panel.php" class="action-btn btn-secondary">
                <i class="fas fa-cog"></i> Admin Panel
            </a>
        </div>

        <!-- Apps List -->
        <div class="app-list" id="appsList">
            <div class="app-item">
                <div class="app-info">
                    <div class="app-name">Loading apps...</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bottom Navigation Bar -->
    <footer class="bottom-nav">
        <a href="index.php" class="nav-item">
            <i class="fas fa-gamepad"></i>
            <span>Games</span>
        </a>
        <a href="index.php" class="nav-item">
            <i class="fas fa-th-large"></i>
            <span>Apps</span>
        </a>
        <a href="search.php" class="nav-item">
            <i class="fas fa-search"></i>
            <span>Search</span>
        </a>
        <a href="developer-dashboard.php" class="nav-item active">
            <i class="fas fa-user-tie"></i>
            <span>Developer</span>
        </a>
    </footer>

    <script>
        // Load developer dashboard data
        async function loadDashboard() {
            try {
                // In real app, fetch from API
                // For demo, using mock data
                const mockData = {
                    totalApps: 5,
                    approvedApps: 3,
                    pendingApps: 2,
                    totalDownloads: 12450,
                    apps: [
                        {
                            id: 1,
                            name: 'Photo Editor Pro',
                            package: 'com.photoeditor.pro',
                            status: 'approved',
                            downloads: 12000,
                            rating: 4.5,
                            created_at: '2024-01-15'
                        },
                        {
                            id: 2,
                            name: 'Music Stream',
                            package: 'com.music.stream',
                            status: 'approved',
                            downloads: 450,
                            rating: 4.3,
                            created_at: '2024-01-20'
                        },
                        {
                            id: 3,
                            name: 'Puzzle Quest',
                            package: 'com.puzzle.quest',
                            status: 'pending',
                            downloads: 0,
                            rating: 0,
                            created_at: '2024-01-25'
                        }
                    ]
                };

                // Update stats
                document.getElementById('totalApps').textContent = mockData.totalApps;
                document.getElementById('approvedApps').textContent = mockData.approvedApps;
                document.getElementById('pendingApps').textContent = mockData.pendingApps;
                document.getElementById('totalDownloads').textContent = mockData.totalDownloads.toLocaleString();

                // Update apps list
                const appsList = document.getElementById('appsList');
                appsList.innerHTML = '';

                mockData.apps.forEach(app => {
                    const appItem = document.createElement('div');
                    appItem.className = 'app-item';
                    appItem.innerHTML = `
                        <div class="app-icon">
                            <i class="fas fa-${app.type === 'game' ? 'gamepad' : 'mobile-alt'}"></i>
                        </div>
                        <div class="app-info">
                            <div class="app-name">${app.name}</div>
                            <div class="app-meta">
                                ${app.package} • ${app.downloads.toLocaleString()} downloads • ${app.rating}★
                            </div>
                        </div>
                        <div class="app-status status-${app.status}">
                            ${app.status.charAt(0).toUpperCase() + app.status.slice(1)}
                        </div>
                    `;
                    appsList.appendChild(appItem);
                });

            } catch (error) {
                console.error('Error loading dashboard:', error);
            }
        }

        document.addEventListener('DOMContentLoaded', loadDashboard);
    </script>
</body>
</html>