<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include database configuration
require_once '../config/database.php';

// Check if request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Invalid request method. Only POST allowed.']);
    exit;
}

// Get form data with proper validation
$name = trim($_POST['appName'] ?? '');
$package = trim($_POST['packageName'] ?? '');
$description = trim($_POST['appDescription'] ?? '');
$category = trim($_POST['appCategory'] ?? '');
$type = $_POST['appType'] ?? '';
$version = trim($_POST['version'] ?? '1.0.0');
$whatsNew = trim($_POST['whatsNew'] ?? '');
$minAndroid = trim($_POST['minAndroid'] ?? '5.0');
$developerId = 1; // In real app, get from session

// Validate required fields
$required_fields = [
    'appName' => 'App Name',
    'packageName' => 'Package Name', 
    'appDescription' => 'Description',
    'appCategory' => 'Category',
    'appType' => 'Type',
    'version' => 'Version'
];

$errors = [];
foreach ($required_fields as $field => $label) {
    if (empty(trim($_POST[$field] ?? ''))) {
        $errors[] = "$label is required";
    }
}

// Validate file uploads
if (!isset($_FILES['appIcon']) || $_FILES['appIcon']['error'] !== UPLOAD_ERR_OK) {
    $errors[] = "App Icon is required";
}

if (!isset($_FILES['appScreenshots']) || empty($_FILES['appScreenshots']['name'][0])) {
    $errors[] = "At least one screenshot is required";
}

if (!isset($_FILES['appFile']) || $_FILES['appFile']['error'] !== UPLOAD_ERR_OK) {
    $errors[] = "App File is required";
}

if (!empty($errors)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => implode(', ', $errors)]);
    exit;
}

// Check if package name already exists
try {
    $stmt = $pdo->prepare("SELECT id FROM apps WHERE package = ?");
    $stmt->execute([$package]);
    
    if ($stmt->fetch()) {
        http_response_code(409);
        echo json_encode(['success' => false, 'message' => 'Package name already exists. Please choose a different package name.']);
        exit;
    }
} catch (PDOException $e) {
    error_log("Database error checking package: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error while checking package availability.']);
    exit;
}

// Handle file uploads
$uploadDir = '../uploads/';
$iconDir = $uploadDir . 'icons/';
$screenshotsDir = $uploadDir . 'screenshots/';
$fileDir = $uploadDir . 'files/';

// Create directories if they don't exist with proper permissions
$directories = [$uploadDir, $iconDir, $screenshotsDir, $fileDir];
foreach ($directories as $dir) {
    if (!is_dir($dir)) {
        if (!mkdir($dir, 0755, true)) {
            error_log("Failed to create directory: $dir");
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => "Failed to create upload directory: $dir"]);
            exit;
        }
    }
    
    // Check if directory is writable
    if (!is_writable($dir)) {
        error_log("Directory not writable: $dir");
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => "Upload directory not writable: $dir"]);
        exit;
    }
}

// Generate unique filenames
function generateUniqueFilename($originalName, $directory) {
    $extension = pathinfo($originalName, PATHINFO_EXTENSION);
    $filename = uniqid() . '_' . time() . '.' . $extension;
    $filename = preg_replace("/[^a-zA-Z0-9._-]/", "_", $filename);
    return $filename;
}

// Process icon upload
$iconName = generateUniqueFilename($_FILES['appIcon']['name'], $iconDir);
$iconPath = $iconDir . $iconName;

if (!move_uploaded_file($_FILES['appIcon']['tmp_name'], $iconPath)) {
    error_log("Failed to move uploaded icon file");
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Failed to upload icon file.']);
    exit;
}

// Process screenshots upload
$screenshotNames = [];
if (isset($_FILES['appScreenshots']) && is_array($_FILES['appScreenshots']['name'])) {
    foreach ($_FILES['appScreenshots']['name'] as $key => $name) {
        if ($_FILES['appScreenshots']['error'][$key] === UPLOAD_ERR_OK) {
            $screenshotName = generateUniqueFilename($name, $screenshotsDir);
            $screenshotPath = $screenshotsDir . $screenshotName;
            
            if (move_uploaded_file($_FILES['appScreenshots']['tmp_name'][$key], $screenshotPath)) {
                $screenshotNames[] = $screenshotName;
            } else {
                error_log("Failed to move uploaded screenshot: $name");
            }
        }
    }
}

// Process app file upload
$fileName = generateUniqueFilename($_FILES['appFile']['name'], $fileDir);
$filePath = $fileDir . $fileName;

if (!move_uploaded_file($_FILES['appFile']['tmp_name'], $filePath)) {
    error_log("Failed to move uploaded app file");
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Failed to upload app file.']);
    
    // Clean up uploaded files
    if (file_exists($iconPath)) unlink($iconPath);
    foreach ($screenshotNames as $screenshotName) {
        $screenshotPath = $screenshotsDir . $screenshotName;
        if (file_exists($screenshotPath)) unlink($screenshotPath);
    }
    exit;
}

// Calculate file size in MB
$fileSize = round($_FILES['appFile']['size'] / (1024 * 1024), 2);

// Insert into database
try {
    $pdo->beginTransaction();
    
    // Insert app
    $stmt = $pdo->prepare("INSERT INTO apps (name, package, description, category, type, icon_url, file_url, file_size_mb, version, whats_new, min_android, developer_id, status, rating, downloads) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', 0.0, 0)");
    
    $iconUrl = 'uploads/icons/' . $iconName;
    $fileUrl = 'uploads/files/' . $fileName;
    
    $stmt->execute([
        $name, $package, $description, $category, $type, 
        $iconUrl, $fileUrl, $fileSize, $version, $whatsNew, 
        $minAndroid, $developerId
    ]);
    
    $appId = $pdo->lastInsertId();
    
    // Insert screenshots
    if (!empty($screenshotNames)) {
        $screenshotStmt = $pdo->prepare("INSERT INTO app_screenshots (app_id, screenshot_url, sort_order) VALUES (?, ?, ?)");
        foreach ($screenshotNames as $index => $screenshotName) {
            $screenshotUrl = 'uploads/screenshots/' . $screenshotName;
            $screenshotStmt->execute([$appId, $screenshotUrl, $index]);
        }
    }
    
    $pdo->commit();
    
    http_response_code(201);
    echo json_encode([
        'success' => true, 
        'message' => 'App uploaded successfully! It will be reviewed by our team.',
        'appId' => $appId
    ]);
    
} catch (PDOException $e) {
    $pdo->rollBack();
    error_log("Database insert error: " . $e->getMessage());
    
    // Clean up uploaded files
    if (file_exists($iconPath)) unlink($iconPath);
    foreach ($screenshotNames as $screenshotName) {
        $screenshotPath = $screenshotsDir . $screenshotName;
        if (file_exists($screenshotPath)) unlink($screenshotPath);
    }
    if (file_exists($filePath)) unlink($filePath);
    
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>