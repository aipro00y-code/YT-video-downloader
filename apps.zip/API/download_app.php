<?php
header('Content-Type: application/json');
require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$appId = $input['appId'] ?? 0;

if ($appId === 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid app ID']);
    exit;
}

try {
    // Increment download count
    $stmt = $pdo->prepare("UPDATE apps SET downloads = downloads + 1 WHERE id = ?");
    $stmt->execute([$appId]);
    
    echo json_encode(['success' => true, 'message' => 'Download count updated']);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>