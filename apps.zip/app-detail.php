<?php
session_start();
$appId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($appId === 0) {
    header('Location: index.php');
    exit;
}

// In a real application, you would fetch the app details from the database
// For this example, we'll use a placeholder
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>App Details - App Store</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Top Navigation Bar -->
    <header class="top-nav">
        <div class="nav-container">
            <a href="index.php" class="back-btn">
                <i class="fas fa-arrow-left"></i>
            </a>
            <div class="logo">
                <h2>App Details</h2>
            </div>
            <div class="search-icon">
                <a href="search.php"><i class="fas fa-search"></i></a>
            </div>
        </div>
    </header>

    <!-- App Details -->
    <div class="app-detail">
        <div class="detail-header">
            <div class="detail-icon">
                <i class="fas fa-mobile-alt"></i>
            </div>
            <div class="detail-info">
                <h1 id="appName">Loading...</h1>
                <div class="package-name" id="packageName">Loading...</div>
                <div class="detail-rating">
                    <i class="fas fa-star"></i>
                    <span id="appRating">Loading...</span>
                </div>
            </div>
        </div>
        
        <div class="detail-description" id="appDescription">
            Loading...
        </div>
        
        <div class="detail-meta">
            <div class="meta-item">
                <span class="meta-label">Category</span>
                <span class="meta-value" id="appCategory">Loading...</span>
            </div>
            <div class="meta-item">
                <span class="meta-label">Size</span>
                <span class="meta-value" id="appSize">Loading...</span>
            </div>
            <div class="meta-item">
                <span class="meta-label">Downloads</span>
                <span class="meta-value" id="appDownloads">Loading...</span>
            </div>
        </div>
        
        <button class="detail-install-btn" id="installBtn">Install</button>
        
        <div class="progress-container" id="progressContainer">
            <div class="progress-bar">
                <div class="progress" id="progressBar"></div>
            </div>
            <div class="progress-text" id="progressText">0%</div>
        </div>
    </div>

    <!-- Bottom Navigation Bar -->
    <footer class="bottom-nav">
        <a href="index.php" class="nav-item">
            <i class="fas fa-gamepad"></i>
            <span>Games</span>
        </a>
        <a href="index.php" class="nav-item">
            <i class="fas fa-th-large"></i>
            <span>Apps</span>
        </a>
        <a href="search.php" class="nav-item">
            <i class="fas fa-search"></i>
            <span>Search</span>
        </a>
        <a href="#" class="nav-item">
            <i class="fas fa-user"></i>
            <span>Profile</span>
        </a>
    </footer>

    <script>
        const appId = <?php echo $appId; ?>;
        const installBtn = document.getElementById('installBtn');
        const progressContainer = document.getElementById('progressContainer');
        const progressBar = document.getElementById('progressBar');
        const progressText = document.getElementById('progressText');
        
        // Load app details
        document.addEventListener('DOMContentLoaded', function() {
            loadAppDetails();
            
            installBtn.addEventListener('click', startInstallation);
        });
        
        async function loadAppDetails() {
            try {
                // In a real application, you would fetch from an API endpoint
                // For this example, we'll simulate the data
                const app = {
                    id: appId,
                    name: 'Photo Editor Pro',
                    package: 'com.photoeditor.pro',
                    description: 'Professional photo editing app with filters and tools. Edit your photos with ease using our intuitive interface and powerful features.',
                    category: 'Photo',
                    type: 'app',
                    file_size_mb: 8.3,
                    rating: 4.5,
                    downloads: 15000
                };
                
                document.getElementById('appName').textContent = app.name;
                document.getElementById('packageName').textContent = app.package;
                document.getElementById('appDescription').textContent = app.description;
                document.getElementById('appCategory').textContent = app.category;
                document.getElementById('appSize').textContent = app.file_size_mb + ' MB';
                document.getElementById('appDownloads').textContent = app.downloads.toLocaleString();
                document.getElementById('appRating').textContent = app.rating;
                
            } catch (error) {
                console.error('Error loading app details:', error);
            }
        }
        
        function startInstallation() {
            installBtn.disabled = true;
            progressContainer.style.display = 'block';
            
            // Simulate download progress
            let progress = 0;
            const interval = setInterval(() => {
                progress += Math.random() * 10;
                if (progress >= 100) {
                    progress = 100;
                    clearInterval(interval);
                    completeInstallation();
                }
                
                progressBar.style.width = progress + '%';
                progressText.textContent = Math.round(progress) + '%';
            }, 200);
        }
        
        function completeInstallation() {
            progressText.textContent = 'Installation Complete!';
            
            // Update download count in the database
            updateDownloadCount();
            
            // Reset button after a delay
            setTimeout(() => {
                installBtn.disabled = false;
                installBtn.textContent = 'Installed';
                progressContainer.style.display = 'none';
            }, 2000);
        }
        
        async function updateDownloadCount() {
            try {
                const response = await fetch('api/download_app.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ appId: appId })
                });
                
                const data = await response.json();
                if (data.success) {
                    console.log('Download count updated');
                }
            } catch (error) {
                console.error('Error updating download count:', error);
            }
        }
    </script>
</body>
</html>