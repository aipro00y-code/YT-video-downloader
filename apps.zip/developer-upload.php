<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Developer Upload - App Store</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .loading {
            display: none;
            text-align: center;
            padding: 20px;
        }
        .loading-spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #4285f4;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 2s linear infinite;
            margin: 0 auto 10px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .file-info {
            margin-top: 5px;
            font-size: 0.8rem;
            color: #666;
        }
        .error {
            color: #d32f2f;
            background: #ffebee;
            padding: 10px;
            border-radius: 4px;
            margin: 10px 0;
        }
        .success {
            color: #388e3c;
            background: #e8f5e9;
            padding: 10px;
            border-radius: 4px;
            margin: 10px 0;
        }
        .screenshot-preview {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin: 10px 0;
        }
        .screenshot-item {
            position: relative;
            width: 100px;
            height: 150px;
        }
        .screenshot-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 8px;
            border: 2px solid #ddd;
        }
        .remove-screenshot {
            position: absolute;
            top: -8px;
            right: -8px;
            background: #f44336;
            color: white;
            border: none;
            border-radius: 50%;
            width: 24px;
            height: 24px;
            cursor: pointer;
            font-size: 12px;
        }
        .form-section {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .form-section h3 {
            margin-bottom: 15px;
            color: #4285f4;
            border-bottom: 2px solid #4285f4;
            padding-bottom: 5px;
        }
        .developer-info {
            background: #e3f2fd;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <!-- Top Navigation Bar -->
    <header class="top-nav">
        <div class="nav-container">
            <a href="index.php" class="back-btn">
                <i class="fas fa-arrow-left"></i>
            </a>
            <div class="logo">
                <h2>Developer Upload</h2>
            </div>
            <div class="nav-actions">
                <a href="developer-dashboard.php" class="nav-btn">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
            </div>
        </div>
    </header>

    <!-- Upload Form -->
    <div class="upload-container">
        <div class="developer-info">
            <h3><i class="fas fa-user-tie"></i> Developer Account</h3>
            <p><strong>Name:</strong> Demo Developer | <strong>Company:</strong> Demo Company</p>
            <p><strong>Email:</strong> developer@example.com</p>
        </div>

        <h2 style="margin-bottom: 20px;">Upload Your App</h2>
        
        <form id="uploadForm" enctype="multipart/form-data">
            <!-- Basic Information Section -->
            <div class="form-section">
                <h3><i class="fas fa-info-circle"></i> Basic Information</h3>
                
                <div class="form-group">
                    <label class="form-label" for="appName">App Name *</label>
                    <input type="text" class="form-input" id="appName" name="appName" required 
                           placeholder="Enter your app name">
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="packageName">Package Name *</label>
                    <input type="text" class="form-input" id="packageName" name="packageName" required 
                           placeholder="e.g., com.company.appname">
                    <div class="file-info">Unique identifier for your app</div>
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="appDescription">Description *</label>
                    <textarea class="form-textarea" id="appDescription" name="appDescription" required 
                              placeholder="Describe your app features and functionality" rows="4"></textarea>
                </div>

                <div class="form-group">
                    <label class="form-label" for="whatsNew">What's New</label>
                    <textarea class="form-textarea" id="whatsNew" name="whatsNew" 
                              placeholder="Describe what's new in this version" rows="3"></textarea>
                </div>
            </div>

            <!-- App Details Section -->
            <div class="form-section">
                <h3><i class="fas fa-cog"></i> App Details</h3>
                
                <div class="form-group">
                    <label class="form-label" for="appCategory">Category *</label>
                    <select class="form-select" id="appCategory" name="appCategory" required>
                        <option value="">Select Category</option>
                        <option value="Business">Business</option>
                        <option value="Communication">Communication</option>
                        <option value="Education">Education</option>
                        <option value="Entertainment">Entertainment</option>
                        <option value="Finance">Finance</option>
                        <option value="Game">Game</option>
                        <option value="Health">Health</option>
                        <option value="Lifestyle">Lifestyle</option>
                        <option value="Music">Music</option>
                        <option value="Photo">Photo</option>
                        <option value="Productivity">Productivity</option>
                        <option value="Shopping">Shopping</option>
                        <option value="Social">Social</option>
                        <option value="Tools">Tools</option>
                        <option value="Travel">Travel</option>
                        <option value="Utility">Utility</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="appType">Type *</label>
                    <select class="form-select" id="appType" name="appType" required>
                        <option value="">Select Type</option>
                        <option value="app">App</option>
                        <option value="game">Game</option>
                    </select>
                </div>

                <div class="form-row">
                    <div class="form-group" style="flex: 1;">
                        <label class="form-label" for="version">Version *</label>
                        <input type="text" class="form-input" id="version" name="version" required 
                               placeholder="e.g., 1.0.0" value="1.0.0">
                    </div>
                    
                    <div class="form-group" style="flex: 1;">
                        <label class="form-label" for="minAndroid">Min Android Version</label>
                        <input type="text" class="form-input" id="minAndroid" name="minAndroid" 
                               placeholder="e.g., 5.0" value="5.0">
                    </div>
                </div>
            </div>

            <!-- Media Files Section -->
            <div class="form-section">
                <h3><i class="fas fa-images"></i> Media Files</h3>
                
                <div class="form-group">
                    <label class="form-label" for="appIcon">App Icon *</label>
                    <input type="file" class="form-input" id="appIcon" name="appIcon" accept="image/*" required>
                    <div class="file-info">PNG, JPG, or GIF (Square, 512x512 recommended, Max: 2MB)</div>
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="appScreenshots">App Screenshots *</label>
                    <input type="file" class="form-input" id="appScreenshots" name="appScreenshots[]" 
                           accept="image/*" multiple required>
                    <div class="file-info">PNG or JPG (Multiple files allowed, 16:9 ratio recommended, Max: 5MB each)</div>
                    
                    <div class="screenshot-preview" id="screenshotPreview"></div>
                </div>
            </div>

            <!-- App File Section -->
            <div class="form-section">
                <h3><i class="fas fa-file-archive"></i> App File</h3>
                
                <div class="form-group">
                    <label class="form-label" for="appFile">App File (APK/ZIP) *</label>
                    <input type="file" class="form-input" id="appFile" name="appFile" accept=".apk,.zip" required>
                    <div class="file-info">APK or ZIP file (Max: 100MB)</div>
                </div>
            </div>
            
            <button type="submit" class="submit-btn" id="submitBtn">
                <i class="fas fa-upload"></i> Upload App
            </button>
        </form>
        
        <div class="loading" id="loadingIndicator">
            <div class="loading-spinner"></div>
            <p>Uploading your app, please wait...</p>
        </div>
        
        <div id="uploadMessage"></div>
    </div>

    <!-- Bottom Navigation Bar -->
    <footer class="bottom-nav">
        <a href="index.php" class="nav-item">
            <i class="fas fa-gamepad"></i>
            <span>Games</span>
        </a>
        <a href="index.php" class="nav-item">
            <i class="fas fa-th-large"></i>
            <span>Apps</span>
        </a>
        <a href="search.php" class="nav-item">
            <i class="fas fa-search"></i>
            <span>Search</span>
        </a>
        <a href="developer-dashboard.php" class="nav-item active">
            <i class="fas fa-user-tie"></i>
            <span>Developer</span>
        </a>
    </footer>

    <script>
        const uploadForm = document.getElementById('uploadForm');
        const uploadMessage = document.getElementById('uploadMessage');
        const loadingIndicator = document.getElementById('loadingIndicator');
        const submitBtn = document.getElementById('submitBtn');
        const screenshotPreview = document.getElementById('screenshotPreview');
        let screenshotFiles = [];

        // File size validation
        function validateFileSize(file, maxSizeMB) {
            const maxSizeBytes = maxSizeMB * 1024 * 1024;
            if (file.size > maxSizeBytes) {
                return `File size must be less than ${maxSizeMB}MB`;
            }
            return null;
        }
        
        // File type validation
        function validateFileType(file, allowedTypes) {
            const fileExtension = file.name.split('.').pop().toLowerCase();
            if (!allowedTypes.includes(fileExtension) && !allowedTypes.includes(file.type)) {
                return `Invalid file type. Allowed: ${allowedTypes.join(', ')}`;
            }
            return null;
        }

        // Preview screenshots
        document.getElementById('appScreenshots').addEventListener('change', function(e) {
            const files = Array.from(e.target.files);
            
            files.forEach(file => {
                if (validateFileSize(file, 5) || validateFileType(file, ['jpg', 'jpeg', 'png'])) {
                    alert(`Invalid screenshot: ${file.name}`);
                    return;
                }

                const reader = new FileReader();
                reader.onload = function(e) {
                    const screenshotItem = document.createElement('div');
                    screenshotItem.className = 'screenshot-item';
                    screenshotItem.innerHTML = `
                        <img src="${e.target.result}" alt="Screenshot Preview">
                        <button type="button" class="remove-screenshot" onclick="removeScreenshot('${file.name}')">
                            <i class="fas fa-times"></i>
                        </button>
                    `;
                    screenshotPreview.appendChild(screenshotItem);
                };
                reader.readAsDataURL(file);
                screenshotFiles.push(file);
            });

            // Update file input
            const dataTransfer = new DataTransfer();
            screenshotFiles.forEach(file => dataTransfer.items.add(file));
            e.target.files = dataTransfer.files;
        });

        // Remove screenshot
        function removeScreenshot(fileName) {
            screenshotFiles = screenshotFiles.filter(file => file.name !== fileName);
            
            // Update file input
            const fileInput = document.getElementById('appScreenshots');
            const dataTransfer = new DataTransfer();
            screenshotFiles.forEach(file => dataTransfer.items.add(file));
            fileInput.files = dataTransfer.files;
            
            // Update preview
            screenshotPreview.innerHTML = '';
            screenshotFiles.forEach(file => {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const screenshotItem = document.createElement('div');
                    screenshotItem.className = 'screenshot-item';
                    screenshotItem.innerHTML = `
                        <img src="${e.target.result}" alt="Screenshot Preview">
                        <button type="button" class="remove-screenshot" onclick="removeScreenshot('${file.name}')">
                            <i class="fas fa-times"></i>
                        </button>
                    `;
                    screenshotPreview.appendChild(screenshotItem);
                };
                reader.readAsDataURL(file);
            });
        }
        
        // Validate form before submission
        function validateForm(formData) {
            const errors = [];
            
            // Validate icon file
            const iconFile = formData.get('appIcon');
            if (iconFile && iconFile.size > 0) {
                const sizeError = validateFileSize(iconFile, 2);
                if (sizeError) errors.push('Icon: ' + sizeError);
                
                const typeError = validateFileType(iconFile, ['jpg', 'jpeg', 'png', 'gif']);
                if (typeError) errors.push('Icon: ' + typeError);
            }

            // Validate screenshots
            const screenshotFiles = formData.getAll('appScreenshots[]');
            if (screenshotFiles.length === 0) {
                errors.push('At least one screenshot is required');
            } else {
                screenshotFiles.forEach((file, index) => {
                    if (file.size > 0) {
                        const sizeError = validateFileSize(file, 5);
                        if (sizeError) errors.push(`Screenshot ${index + 1}: ${sizeError}`);
                        
                        const typeError = validateFileType(file, ['jpg', 'jpeg', 'png']);
                        if (typeError) errors.push(`Screenshot ${index + 1}: ${typeError}`);
                    }
                });
            }
            
            // Validate app file
            const appFile = formData.get('appFile');
            if (appFile && appFile.size > 0) {
                const sizeError = validateFileSize(appFile, 100);
                if (sizeError) errors.push('App File: ' + sizeError);
                
                const typeError = validateFileType(appFile, ['apk', 'zip']);
                if (typeError) errors.push('App File: ' + typeError);
            }
            
            return errors;
        }
        
        uploadForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            // Show loading indicator
            loadingIndicator.style.display = 'block';
            submitBtn.disabled = true;
            uploadMessage.innerHTML = '';
            
            const formData = new FormData(this);
            
            // Validate files
            const validationErrors = validateForm(formData);
            if (validationErrors.length > 0) {
                loadingIndicator.style.display = 'none';
                submitBtn.disabled = false;
                uploadMessage.innerHTML = `<div class="error"><strong>Validation Errors:</strong><br>${validationErrors.join('<br>')}</div>`;
                return;
            }
            
            try {
                const response = await fetch('api/upload_app.php', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.success) {
                    uploadMessage.innerHTML = `<div class="success">
                        <strong>Success!</strong> ${data.message}
                        <br><small>App ID: ${data.appId} - Status: Pending Review</small>
                        <br><a href="developer-dashboard.php" style="color: #388e3c; text-decoration: underline;">View in Dashboard</a>
                    </div>`;
                    uploadForm.reset();
                    screenshotPreview.innerHTML = '';
                    screenshotFiles = [];
                } else {
                    uploadMessage.innerHTML = `<div class="error">
                        <strong>Upload Failed:</strong> ${data.message}
                    </div>`;
                }
            } catch (error) {
                console.error('Error uploading app:', error);
                uploadMessage.innerHTML = `<div class="error">
                    <strong>Network Error:</strong> Failed to upload app. Please check your connection and try again.
                </div>`;
            } finally {
                loadingIndicator.style.display = 'none';
                submitBtn.disabled = false;
            }
        });
        
        // Real-time file validation
        document.getElementById('appIcon').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const error = validateFileSize(file, 2) || validateFileType(file, ['jpg', 'jpeg', 'png', 'gif']);
                if (error) {
                    alert('Icon Error: ' + error);
                    e.target.value = '';
                }
            }
        });
        
        document.getElementById('appFile').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const error = validateFileSize(file, 100) || validateFileType(file, ['apk', 'zip']);
                if (error) {
                    alert('App File Error: ' + error);
                    e.target.value = '';
                }
            }
        });
    </script>
</body>
</html>