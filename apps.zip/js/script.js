// DOM Elements
const hamburger = document.getElementById('hamburger');
const sideMenu = document.getElementById('sideMenu');
const closeMenu = document.getElementById('closeMenu');
const forDevelopers = document.getElementById('forDevelopers');
const tabs = document.querySelectorAll('.tab');
const featuredBanner = document.getElementById('featuredBanner');
const appSections = {
    suggested: document.getElementById('suggestedApps'),
    trending: document.getElementById('trendingApps'),
    topGames: document.getElementById('topGames'),
    recommended: document.getElementById('recommendedApps')
};

// Event Listeners
document.addEventListener('DOMContentLoaded', function() {
    // Load initial data
    loadFeaturedApp();
    loadAppSections();
    
    // Set up event listeners
    hamburger.addEventListener('click', toggleSideMenu);
    closeMenu.addEventListener('click', toggleSideMenu);
    forDevelopers.addEventListener('click', redirectToDeveloperUpload);
    
    // Tab switching
    tabs.forEach(tab => {
        tab.addEventListener('click', function(e) {
            e.preventDefault();
            switchTab(this.dataset.tab);
        });
    });
    
    // Infinite scroll
    window.addEventListener('scroll', handleScroll);
});

// Toggle Side Menu
function toggleSideMenu() {
    sideMenu.classList.toggle('active');
}

// Redirect to Developer Upload
function redirectToDeveloperUpload() {
    window.location.href = 'developer-upload.php';
}

// Switch Tabs
function switchTab(tabName) {
    // Remove active class from all tabs
    tabs.forEach(tab => tab.classList.remove('active'));
    
    // Add active class to clicked tab
    document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
    
    // Load content for the selected tab
    loadTabContent(tabName);
}

// Load Featured App
async function loadFeaturedApp() {
    try {
        const response = await fetch('api/get_featured.php');
        const data = await response.json();
        
        if (data.success) {
            const app = data.app;
            featuredBanner.innerHTML = `
                <div class="banner-content">
                    <div class="banner-icon">
                        <i class="fas fa-mobile-alt"></i>
                    </div>
                    <div class="banner-text">
                        <h2>${app.name}</h2>
                        <p>${app.description}</p>
                        <button class="install-btn" onclick="viewAppDetail(${app.id})">Install</button>
                    </div>
                </div>
            `;
        }
    } catch (error) {
        console.error('Error loading featured app:', error);
    }
}

// Load App Sections
async function loadAppSections() {
    try {
        // Load suggested apps
        const suggestedResponse = await fetch('api/get_suggested.php');
        const suggestedData = await suggestedResponse.json();
        if (suggestedData.success) {
            renderAppGrid(appSections.suggested, suggestedData.apps);
        }
        
        // Load trending apps
        const trendingResponse = await fetch('api/get_top_apps.php');
        const trendingData = await trendingResponse.json();
        if (trendingData.success) {
            renderAppGrid(appSections.trending, trendingData.apps);
        }
        
        // Load top games
        const gamesResponse = await fetch('api/get_top_games.php');
        const gamesData = await gamesResponse.json();
        if (gamesData.success) {
            renderAppGrid(appSections.topGames, gamesData.apps);
        }
        
        // Load recommended apps
        const recommendedResponse = await fetch('api/get_suggested.php');
        const recommendedData = await recommendedResponse.json();
        if (recommendedData.success) {
            renderAppGrid(appSections.recommended, recommendedData.apps);
        }
    } catch (error) {
        console.error('Error loading app sections:', error);
    }
}

// Render App Grid
function renderAppGrid(container, apps) {
    container.innerHTML = '';
    
    apps.forEach(app => {
        const appCard = document.createElement('div');
        appCard.className = 'app-card';
        appCard.innerHTML = `
            <div class="app-icon">
                <i class="fas fa-${app.type === 'game' ? 'gamepad' : 'mobile-alt'}"></i>
            </div>
            <div class="app-name">${app.name}</div>
            <div class="app-category">${app.category}</div>
            <div class="app-rating">
                <i class="fas fa-star"></i>
                <span>${app.rating}</span>
            </div>
            <button class="card-install-btn" onclick="viewAppDetail(${app.id})">Install</button>
        `;
        container.appendChild(appCard);
    });
}

// Load Tab Content
function loadTabContent(tabName) {
    // This would load different content based on the selected tab
    console.log(`Loading content for ${tabName} tab`);
}

// Handle Infinite Scroll
function handleScroll() {
    const { scrollTop, scrollHeight, clientHeight } = document.documentElement;
    
    if (scrollTop + clientHeight >= scrollHeight - 100) {
        // Load more content
        loadMoreApps();
    }
}

// Load More Apps (for infinite scroll)
function loadMoreApps() {
    // This would fetch more apps from the API
    console.log('Loading more apps...');
}

// View App Detail
function viewAppDetail(appId) {
    window.location.href = `app-detail.php?id=${appId}`;
}