<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search - App Store</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Top Navigation Bar -->
    <header class="top-nav">
        <div class="nav-container">
            <a href="index.php" class="back-btn">
                <i class="fas fa-arrow-left"></i>
            </a>
            <div class="logo">
                <h2>Search</h2>
            </div>
            <div class="search-icon">
                <i class="fas fa-search"></i>
            </div>
        </div>
    </header>

    <!-- Search Content -->
    <div class="search-container">
        <div class="search-box">
            <input type="text" class="search-input" id="searchInput" placeholder="Search for apps or games...">
        </div>
        <div class="search-results" id="searchResults">
            <!-- Search results will be loaded here -->
        </div>
    </div>

    <!-- Bottom Navigation Bar -->
    <footer class="bottom-nav">
        <a href="index.php" class="nav-item">
            <i class="fas fa-gamepad"></i>
            <span>Games</span>
        </a>
        <a href="index.php" class="nav-item">
            <i class="fas fa-th-large"></i>
            <span>Apps</span>
        </a>
        <a href="search.php" class="nav-item active">
            <i class="fas fa-search"></i>
            <span>Search</span>
        </a>
        <a href="#" class="nav-item">
            <i class="fas fa-user"></i>
            <span>Profile</span>
        </a>
    </footer>

    <script>
        const searchInput = document.getElementById('searchInput');
        const searchResults = document.getElementById('searchResults');
        
        // Search as user types
        searchInput.addEventListener('input', debounce(handleSearch, 300));
        
        function debounce(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        }
        
        async function handleSearch() {
            const query = searchInput.value.trim();
            
            if (query.length === 0) {
                searchResults.innerHTML = '';
                return;
            }
            
            try {
                const response = await fetch(`api/search_apps.php?q=${encodeURIComponent(query)}`);
                const data = await response.json();
                
                if (data.success) {
                    renderSearchResults(data.apps);
                } else {
                    searchResults.innerHTML = '<p>No results found.</p>';
                }
            } catch (error) {
                console.error('Error searching apps:', error);
                searchResults.innerHTML = '<p>Error searching apps. Please try again.</p>';
            }
        }
        
        function renderSearchResults(apps) {
            if (apps.length === 0) {
                searchResults.innerHTML = '<p>No apps found matching your search.</p>';
                return;
            }
            
            let html = '';
            apps.forEach(app => {
                html += `
                    <div class="app-card">
                        <div class="app-icon">
                            <i class="fas fa-${app.type === 'game' ? 'gamepad' : 'mobile-alt'}"></i>
                        </div>
                        <div class="app-name">${app.name}</div>
                        <div class="app-category">${app.category}</div>
                        <div class="app-rating">
                            <i class="fas fa-star"></i>
                            <span>${app.rating}</span>
                        </div>
                        <button class="card-install-btn" onclick="viewAppDetail(${app.id})">Install</button>
                    </div>
                `;
            });
            
            searchResults.innerHTML = html;
        }
        
        function viewAppDetail(appId) {
            window.location.href = `app-detail.php?id=${appId}`;
        }
    </script>
</body>
</html>