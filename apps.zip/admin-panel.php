<?php
session_start();
// In real app, check admin authentication
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - App Store</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .admin-header {
            background: linear-gradient(135deg, #4285f4, #34a853);
            color: white;
            padding: 20px;
            margin-bottom: 30px;
            border-radius: 10px;
        }
        .admin-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        .stat-number {
            font-size: 2rem;
            font-weight: bold;
            color: #4285f4;
            margin-bottom: 5px;
        }
        .stat-label {
            color: #666;
            font-size: 0.9rem;
        }
        .admin-tabs {
            display: flex;
            border-bottom: 2px solid #eee;
            margin-bottom: 20px;
        }
        .admin-tab {
            padding: 10px 20px;
            cursor: pointer;
            border-bottom: 2px solid transparent;
            margin-bottom: -2px;
        }
        .admin-tab.active {
            border-bottom-color: #4285f4;
            color: #4285f4;
            font-weight: 500;
        }
        .tab-content {
            display: none;
        }
        .tab-content.active {
            display: block;
        }
        .app-list {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .app-item {
            display: flex;
            align-items: center;
            padding: 15px 20px;
            border-bottom: 1px solid #eee;
        }
        .app-item:last-child {
            border-bottom: none;
        }
        .app-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            background: #f0f0f0;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 1.2rem;
            color: #4285f4;
        }
        .app-info {
            flex: 1;
        }
        .app-name {
            font-weight: 500;
            margin-bottom: 5px;
        }
        .app-meta {
            font-size: 0.8rem;
            color: #666;
        }
        .app-actions {
            display: flex;
            gap: 10px;
        }
        .action-btn {
            padding: 5px 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.8rem;
            font-weight: 500;
        }
        .btn-approve {
            background: #d4edda;
            color: #155724;
        }
        .btn-reject {
            background: #f8d7da;
            color: #721c24;
        }
        .btn-view {
            background: #d1ecf1;
            color: #0c5460;
        }
        .status-badge {
            padding: 3px 8px;
            border-radius: 10px;
            font-size: 0.7rem;
            font-weight: 500;
            margin-left: 10px;
        }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-approved { background: #d4edda; color: #155724; }
        .status-rejected { background: #f8d7da; color: #721c24; }
        .developer-info {
            font-size: 0.8rem;
            color: #666;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <!-- Top Navigation Bar -->
    <header class="top-nav">
        <div class="nav-container">
            <a href="index.php" class="back-btn">
                <i class="fas fa-arrow-left"></i>
            </a>
            <div class="logo">
                <h2>Admin Panel</h2>
            </div>
            <div class="nav-actions">
                <a href="developer-dashboard.php" class="nav-btn">
                    <i class="fas fa-tachometer-alt"></i> Developer Dashboard
                </a>
            </div>
        </div>
    </header>

    <div class="upload-container">
        <!-- Admin Header -->
        <div class="admin-header">
            <h1><i class="fas fa-cogs"></i> App Store Administration</h1>
            <p>Manage apps, developers, and platform content</p>
        </div>

        <!-- Admin Stats -->
        <div class="admin-stats">
            <div class="stat-card">
                <div class="stat-number" id="totalApps">0</div>
                <div class="stat-label">Total Apps</div>
            </div>
            <div class="stat-card">
                <div class="stat-number" id="pendingReview">0</div>
                <div class="stat-label">Pending Review</div>
            </div>
            <div class="stat-card">
                <div class="stat-number" id="totalDevelopers">0</div>
                <div class="stat-label">Developers</div>
            </div>
            <div class="stat-card">
                <div class="stat-number" id="totalDownloads">0</div>
                <div class="stat-label">Total Downloads</div>
            </div>
        </div>

        <!-- Admin Tabs -->
        <div class="admin-tabs">
            <div class="admin-tab active" data-tab="pending">Pending Review</div>
            <div class="admin-tab" data-tab="all">All Apps</div>
            <div class="admin-tab" data-tab="developers">Developers</div>
            <div class="admin-tab" data-tab="reports">Reports</div>
        </div>

        <!-- Tab Contents -->
        <div class="tab-content active" id="pending-tab">
            <div class="app-list" id="pendingApps">
                <div class="app-item">
                    <div class="app-info">
                        <div class="app-name">Loading pending apps...</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="tab-content" id="all-tab">
            <div class="app-list" id="allApps">
                <div class="app-item">
                    <div class="app-info">
                        <div class="app-name">Loading all apps...</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="tab-content" id="developers-tab">
            <div class="app-list" id="developersList">
                <div class="app-item">
                    <div class="app-info">
                        <div class="app-name">Loading developers...</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="tab-content" id="reports-tab">
            <div class="stat-card">
                <h3>Platform Reports</h3>
                <p>Download platform analytics and reports</p>
                <button class="action-btn btn-view" style="margin-top: 10px;">
                    <i class="fas fa-download"></i> Download Report
                </button>
            </div>
        </div>
    </div>

    <!-- Bottom Navigation Bar -->
    <footer class="bottom-nav">
        <a href="index.php" class="nav-item">
            <i class="fas fa-gamepad"></i>
            <span>Games</span>
        </a>
        <a href="index.php" class="nav-item">
            <i class="fas fa-th-large"></i>
            <span>Apps</span>
        </a>
        <a href="search.php" class="nav-item">
            <i class="fas fa-search"></i>
            <span>Search</span>
        </a>
        <a href="admin-panel.php" class="nav-item active">
            <i class="fas fa-user-shield"></i>
            <span>Admin</span>
        </a>
    </footer>

    <script>
        // Tab switching
        document.querySelectorAll('.admin-tab').forEach(tab => {
            tab.addEventListener('click', function() {
                // Remove active class from all tabs
                document.querySelectorAll('.admin-tab').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
                
                // Add active class to clicked tab
                this.classList.add('active');
                document.getElementById(this.dataset.tab + '-tab').classList.add('active');
                
                // Load tab data
                loadTabData(this.dataset.tab);
            });
        });

        // Load admin data
        async function loadAdminData() {
            try {
                // Mock data for demonstration
                const mockData = {
                    totalApps: 25,
                    pendingReview: 5,
                    totalDevelopers: 8,
                    totalDownloads: 125430,
                    pendingApps: [
                        {
                            id: 3,
                            name: 'Puzzle Quest',
                            package: 'com.puzzle.quest',
                            developer: 'Demo Developer',
                            type: 'game',
                            category: 'Puzzle',
                            version: '1.0.0',
                            submitted: '2024-01-25'
                        },
                        {
                            id: 4,
                            name: 'Fitness Tracker',
                            package: 'com.fitness.tracker',
                            developer: 'Health Apps Inc',
                            type: 'app',
                            category: 'Health',
                            version: '2.1.0',
                            submitted: '2024-01-26'
                        }
                    ],
                    allApps: [
                        {
                            id: 1,
                            name: 'Photo Editor Pro',
                            package: 'com.photoeditor.pro',
                            developer: 'Demo Developer',
                            type: 'app',
                            status: 'approved',
                            downloads: 12000,
                            rating: 4.5
                        },
                        {
                            id: 2,
                            name: 'Music Stream',
                            package: 'com.music.stream',
                            developer: 'Demo Developer',
                            type: 'app',
                            status: 'approved',
                            downloads: 450,
                            rating: 4.3
                        }
                    ],
                    developers: [
                        {
                            id: 1,
                            name: 'Demo Developer',
                            email: 'developer@example.com',
                            company: 'Demo Company',
                            appsCount: 3,
                            joined: '2024-01-01'
                        },
                        {
                            id: 2,
                            name: 'Health Apps Inc',
                            email: 'contact@healthapps.com',
                            company: 'Health Apps Inc',
                            appsCount: 2,
                            joined: '2024-01-10'
                        }
                    ]
                };

                // Update stats
                document.getElementById('totalApps').textContent = mockData.totalApps;
                document.getElementById('pendingReview').textContent = mockData.pendingReview;
                document.getElementById('totalDevelopers').textContent = mockData.totalDevelopers;
                document.getElementById('totalDownloads').textContent = mockData.totalDownloads.toLocaleString();

                // Load initial tab data
                loadTabData('pending');

            } catch (error) {
                console.error('Error loading admin data:', error);
            }
        }

        // Load tab-specific data
        function loadTabData(tab) {
            const mockData = {
                pending: [
                    {
                        id: 3,
                        name: 'Puzzle Quest',
                        package: 'com.puzzle.quest',
                        developer: 'Demo Developer',
                        type: 'game',
                        category: 'Puzzle',
                        version: '1.0.0',
                        submitted: '2024-01-25'
                    },
                    {
                        id: 4,
                        name: 'Fitness Tracker',
                        package: 'com.fitness.tracker',
                        developer: 'Health Apps Inc',
                        type: 'app',
                        category: 'Health',
                        version: '2.1.0',
                        submitted: '2024-01-26'
                    }
                ],
                all: [
                    {
                        id: 1,
                        name: 'Photo Editor Pro',
                        package: 'com.photoeditor.pro',
                        developer: 'Demo Developer',
                        type: 'app',
                        status: 'approved',
                        downloads: 12000,
                        rating: 4.5
                    },
                    {
                        id: 2,
                        name: 'Music Stream',
                        package: 'com.music.stream',
                        developer: 'Demo Developer',
                        type: 'app',
                        status: 'approved',
                        downloads: 450,
                        rating: 4.3
                    }
                ],
                developers: [
                    {
                        id: 1,
                        name: 'Demo Developer',
                        email: 'developer@example.com',
                        company: 'Demo Company',
                        appsCount: 3,
                        joined: '2024-01-01'
                    },
                    {
                        id: 2,
                        name: 'Health Apps Inc',
                        email: 'contact@healthapps.com',
                        company: 'Health Apps Inc',
                        appsCount: 2,
                        joined: '2024-01-10'
                    }
                ]
            };

            const container = document.getElementById(tab + (tab === 'developers' ? 'List' : 'Apps'));
            
            if (mockData[tab]) {
                container.innerHTML = '';
                mockData[tab].forEach(item => {
                    const itemElement = document.createElement('div');
                    itemElement.className = 'app-item';
                    
                    if (tab === 'pending') {
                        itemElement.innerHTML = `
                            <div class="app-icon">
                                <i class="fas fa-${item.type === 'game' ? 'gamepad' : 'mobile-alt'}"></i>
                            </div>
                            <div class="app-info">
                                <div class="app-name">${item.name}</div>
                                <div class="app-meta">
                                    ${item.package} • ${item.category} • v${item.version}
                                </div>
                                <div class="developer-info">
                                    Developer: ${item.developer} • Submitted: ${item.submitted}
                                </div>
                            </div>
                            <div class="app-actions">
                                <button class="action-btn btn-view" onclick="viewApp(${item.id})">
                                    <i class="fas fa-eye"></i> View
                                </button>
                                <button class="action-btn btn-approve" onclick="approveApp(${item.id})">
                                    <i class="fas fa-check"></i> Approve
                                </button>
                                <button class="action-btn btn-reject" onclick="rejectApp(${item.id})">
                                    <i class="fas fa-times"></i> Reject
                                </button>
                            </div>
                        `;
                    } else if (tab === 'all') {
                        itemElement.innerHTML = `
                            <div class="app-icon">
                                <i class="fas fa-${item.type === 'game' ? 'gamepad' : 'mobile-alt'}"></i>
                            </div>
                            <div class="app-info">
                                <div class="app-name">${item.name}</div>
                                <div class="app-meta">
                                    ${item.package} • ${item.downloads.toLocaleString()} downloads • ${item.rating}★
                                </div>
                                <div class="developer-info">
                                    Developer: ${item.developer}
                                </div>
                            </div>
                            <div class="app-actions">
                                <span class="status-badge status-${item.status}">${item.status}</span>
                                <button class="action-btn btn-view" onclick="viewApp(${item.id})">
                                    <i class="fas fa-eye"></i> View
                                </button>
                            </div>
                        `;
                    } else if (tab === 'developers') {
                        itemElement.innerHTML = `
                            <div class="app-icon">
                                <i class="fas fa-user-tie"></i>
                            </div>
                            <div class="app-info">
                                <div class="app-name">${item.name}</div>
                                <div class="app-meta">
                                    ${item.email} • ${item.company}
                                </div>
                                <div class="developer-info">
                                    ${item.appsCount} apps • Joined: ${item.joined}
                                </div>
                            </div>
                            <div class="app-actions">
                                <button class="action-btn btn-view" onclick="viewDeveloper(${item.id})">
                                    <i class="fas fa-eye"></i> View
                                </button>
                            </div>
                        `;
                    }
                    
                    container.appendChild(itemElement);
                });
            }
        }

        // Admin actions
        function viewApp(appId) {
            alert(`View app details for ID: ${appId}`);
            // In real app, redirect to app detail page
        }

        function approveApp(appId) {
            if (confirm('Are you sure you want to approve this app?')) {
                alert(`App approved: ${appId}`);
                // In real app, call API to update status
                loadTabData('pending');
            }
        }

        function rejectApp(appId) {
            const reason = prompt('Please enter rejection reason:');
            if (reason) {
                alert(`App rejected: ${appId}\nReason: ${reason}`);
                // In real app, call API to update status
                loadTabData('pending');
            }
        }

        function viewDeveloper(developerId) {
            alert(`View developer details for ID: ${developerId}`);
            // In real app, show developer details
        }

        document.addEventListener('DOMContentLoaded', loadAdminData);
    </script>
</body>
</html>